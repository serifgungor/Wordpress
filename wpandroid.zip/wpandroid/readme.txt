=== Plugin Name ===
Contributors: WP ANDROID
Plugin Name: WP ANDROID
Tags: wpandroid, wp, android, apps, app, android plugin, google android, app creator, iphone, android market, ckeditor, text editor
Author URI: http://www.wpandroid.com
Donate link: http://www.wpandroid.com
Requires at least: 2.0.2
Tested up to: 3.0.1
Stable tag: 1.0

Create Android Apps via your Wordpress Admin Dashboard. No Coding Required.

== Description ==

Create Android Apps via your Wordpress Admin Dashboard. No Coding Required and its a free plugin.  Publish you apps on the Android Market.  300,000 new Android devices are Activated on a Daily Basis.  Build an Android App Today.


== Installation ==

*Installation:*

1) Download the plugin and save the zip file to your hard drive.
2) In your wp admin, click on the “plugins” tab, then “upload”
3) Locate the zip file, and click upload it.
4) Activate the plugin.
5) click on the setting tab in the wp-admin sidebar… and click on WPANDROID plugin.
6) Register for free, and click Create a New App.
7) Input your content in the 4 editors (each app has 4 pages)..  Even edit the "Source" and embed your own code!
8) Download your app from the My Apps link.. (Save it to your computer.)
9) Publish your app on the Live Android Market!


There's no limit to your creativity.  Create as many apps as you want!


== Frequently Asked Questions ==

*Do you offer Support?*

Yes.  Click on the "Support Forum" link on the bottom of the plugin.

== Screenshots ==

= Screenshots can be found at our site www.wpandroid.com

== Upgrade Notice ==

= This is the latest upgraded version.

== Changelog ==

= 1.0 =
* First Wordpress hosted release of our plugin.
* Plugin was release first on the internet.