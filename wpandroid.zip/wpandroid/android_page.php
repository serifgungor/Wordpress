<?php
echo "this is a test page";
?>